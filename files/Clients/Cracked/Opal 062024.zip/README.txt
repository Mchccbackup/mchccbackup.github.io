put opal.jar into ur .minecraft and the mods in mods folder
add fabric api for 1.20.6
del all jvm args, then add -XX:+DisableAttachMechanism into ur jvm args

OPAL.JAR IS NOT A MOD, DO NOT PUT IT INTO MODS FOLDER!!!

Opal by the DRPK
Given by MCC
Brought to you by MCHCC