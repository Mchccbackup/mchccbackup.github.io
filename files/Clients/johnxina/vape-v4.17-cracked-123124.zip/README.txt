Cracked by Team John Xina Spec in less than 1 minute.
GH: https://github.com/JohnXina-spec

Supported:
- Lunar Client 1.8.9

Other 1.8.9 clients may be supported but have not tested. 1.12/1.16 are not supported.

-- Pathches 2024.12.5 07:38

Fixes Path issue

-- Patches 2024.12.31 01:56

Updated to 4.17
Fixed config system