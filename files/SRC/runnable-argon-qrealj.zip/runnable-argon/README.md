Deobfuscation: < 15 minutes (100 line transformer)

Remapping: < 1 day (50% remapped automatically)

# Credits
qreaj - not using a custom rt.jar

argon devs - pasting half the client (https://github.com/ayaxdev/archive/tree/858adf7555a49153950845d41b5680de3c315229/clients/argon%2026.05/src/main/java/ja/tabio/argon, etc)

3000IQPlay - jar & lawsuit

### Running from source
- Clone this repository
- Run `./gradlew runClient`
