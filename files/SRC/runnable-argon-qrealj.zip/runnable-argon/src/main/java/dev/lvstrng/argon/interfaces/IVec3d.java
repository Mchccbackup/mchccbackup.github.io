// 
// Decompiled by the rizzer xd
// 

package dev.lvstrng.argon.interfaces;

public interface IVec3d {
    void method596(final net.minecraft.util.math.Vec3d p0, final float p1, final boolean p2);
}
