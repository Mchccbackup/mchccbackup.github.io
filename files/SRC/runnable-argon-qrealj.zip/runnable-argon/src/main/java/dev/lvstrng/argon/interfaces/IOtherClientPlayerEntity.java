// 
// Decompiled by the rizzer xd
// 

package dev.lvstrng.argon.interfaces;

public interface IOtherClientPlayerEntity {
    void method286(final float p0);

    void method287(final float p0);

    void method288(final boolean p0);
}
