package dev.lvstrng.argon.auth;

public class AuthThatDoesNothing {
//    public static native void lol();
}
