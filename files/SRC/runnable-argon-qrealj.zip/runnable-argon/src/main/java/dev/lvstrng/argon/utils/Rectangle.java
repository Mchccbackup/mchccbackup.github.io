package dev.lvstrng.argon.utils;

class Rectangle {
    public int x;
    public int y;
    public int width;
    public int height;

    Rectangle(final int field510, final int field511, final int field512, final int field513) {
        this.x = field510;
        this.y = field511;
        this.width = field512;
        this.height = field513;
    }

    Rectangle() {
    }

    public int method385() {
        return this.x;
    }

    public int method386() {
        return this.y;
    }

    public int method387() {
        return this.width;
    }

    public int method388() {
        return this.height;
    }
}