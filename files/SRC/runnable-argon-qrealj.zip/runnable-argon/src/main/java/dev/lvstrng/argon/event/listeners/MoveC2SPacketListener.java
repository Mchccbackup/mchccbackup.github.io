package dev.lvstrng.argon.event.listeners;

import dev.lvstrng.argon.event.EventListener;

public interface MoveC2SPacketListener extends EventListener {
    void onMoveC2SPacket();
}
