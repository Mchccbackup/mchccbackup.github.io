// 
// Decompiled by the rizzer xd
// 

package dev.lvstrng.argon.auth;

public record CustomByteResponseAYOOOO(int LENGTH, byte[] BYTEARRAY) {

}
