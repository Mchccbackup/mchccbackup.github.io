package dev.lvstrng.argon.event.listeners;

import dev.lvstrng.argon.event.EventListener;

public interface MouseUpdateListener extends EventListener {
    void onMouseUpdate();
}
