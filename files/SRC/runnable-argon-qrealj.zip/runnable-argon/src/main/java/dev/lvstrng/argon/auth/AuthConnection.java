package dev.lvstrng.argon.auth;

public class AuthConnection {
//    public static native void cold();
}