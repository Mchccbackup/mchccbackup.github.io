// 
// Decompiled by the rizzer xd
// 

package dev.lvstrng.argon.utils;

import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerEntity;

public class CustomInventoryScreen extends InventoryScreen {
    public CustomInventoryScreen(final PlayerEntity player) {
        super(player);
    }
}
