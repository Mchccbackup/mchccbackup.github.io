// 
// Decompiled by the rizzer xd
// 

package dev.lvstrng.argon;

import net.fabricmc.api.ModInitializer;

public final class Initializer implements ModInitializer {
    @Override
    public void onInitialize() {
        new Argon();
    }
}
