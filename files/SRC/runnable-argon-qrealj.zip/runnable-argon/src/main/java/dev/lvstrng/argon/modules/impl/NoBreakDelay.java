// 
// Decompiled by the rizzer xd
// 

package dev.lvstrng.argon.modules.impl;

import dev.lvstrng.argon.modules.Category;
import dev.lvstrng.argon.modules.Module;

public final class NoBreakDelay extends Module {
    public NoBreakDelay() {
        super("No Break Delay", "Removes the break delay from mining blocks", 0, Category.MISC);
    }
}
