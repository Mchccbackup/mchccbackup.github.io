package dev.lvstrng.argon.event;

public interface EventListener extends java.util.EventListener {
}
