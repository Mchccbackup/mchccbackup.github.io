// 
// Decompiled by the rizzer xd
// 

package dev.lvstrng.argon.interfaces;

public interface IKeybinding {
    boolean gwQH();

    boolean isPressed();

    void gwQI();
}
