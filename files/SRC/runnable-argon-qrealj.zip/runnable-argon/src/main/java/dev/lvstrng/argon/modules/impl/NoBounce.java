// 
// Decompiled by the rizzer xd
// 

package dev.lvstrng.argon.modules.impl;

import dev.lvstrng.argon.modules.Category;
import dev.lvstrng.argon.modules.Module;

public final class NoBounce extends Module {
    public NoBounce() {
        super("No Bounce", "Removes the crystal bounce", 0, Category.RENDER);
    }
}
