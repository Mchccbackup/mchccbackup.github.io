package dev.lvstrng.argon.utils;

public enum ESPDisplayMode {
    Normal("????");

    public final String name;

    ESPDisplayMode(final String name) {
        this.name = name;
    }
}
