// 
// Decompiled by the rizzer xd
// 

package dev.lvstrng.argon.interfaces;

import net.minecraft.client.render.BufferBuilder;
import org.joml.Matrix4f;

public interface IBufferedBuilder {
    void method373(final BufferBuilder p0, final float p1, final float p2, final float p3, final float p4, final float p5, final float p6, final float p7, final float p8, final float p9, final float p10, final Matrix4f p11);
}
