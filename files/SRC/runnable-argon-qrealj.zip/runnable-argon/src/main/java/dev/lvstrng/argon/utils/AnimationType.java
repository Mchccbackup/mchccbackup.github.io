// 
// Decompiled by the rizzer xd
// 

package dev.lvstrng.argon.utils;

public enum AnimationType {
    NORMAL("Normal"),
    POSITIVE("Positive"),
    OFF("Off");

    public final String name;

    AnimationType(final String name) {
        this.name = name;
    }
}
