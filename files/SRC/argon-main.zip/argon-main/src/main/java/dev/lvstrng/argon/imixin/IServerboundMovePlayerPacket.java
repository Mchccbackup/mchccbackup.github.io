package dev.lvstrng.argon.imixin;


public interface IServerboundMovePlayerPacket {
	void setYRot(float yRot);

	void setXRot(float xRot);

	void setHasRot(boolean hasRot);
}