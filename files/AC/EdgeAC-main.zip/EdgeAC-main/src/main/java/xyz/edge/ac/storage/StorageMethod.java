package xyz.edge.ac.storage;

public enum StorageMethod
{
    FLAT_FILE, 
    MONGO;
}
