EdgeAC! RealTrippy strikes once again! (Cyanade#7430 now)
